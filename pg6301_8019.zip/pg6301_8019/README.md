* "npm install" - to install all det dependencies.
* "npm start" - to start det project.
* The server wil start at http://localhos:8080
* The client starts on http://localhos:1234

* Most of the code are from the lectures. The project is a combination of what I've learned in class.
* So none of my tests ran, so I guess I am at 0%... :(

* for some reason this script (https://unpkg.com/regenerator-runtime@0.13.1/runtime.js) solved my problem when Google Authentication didn't give me the option to login. There's probably a smarter way, but this one was the easiest for me. (https://stackoverflow.com/questions/11485271/google-oauth-2-authorization-error-redirect-uri-mismatch)
* I tried to adjust so that you get redirected to the Google profile page after you sign in, But for some reason it won't, unfortunately I couldn't find out why.
* Your profile won't appear in the Google profile page. It was supposed to that, the code is there for that. But unfortunately I couldn't find out why.
* I did not manage to export the flight-data from the server.js to OrdersPage.

* my Client Secret for OAuth 2.0 Client is:
  u85lcFHr9TNY7tUguwEYFtWl