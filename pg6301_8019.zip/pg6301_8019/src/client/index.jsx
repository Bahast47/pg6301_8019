import * as ReactDOM from "react-dom";
import * as React from "react";
import { Application } from "./Application";

ReactDOM.render(<Application />, document.getElementById("app"));
