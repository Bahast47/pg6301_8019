import React from "react";

export function LoadingView() {
  return <div>Loading ...</div>;
}
